'responseCard': {
    'contentType': 'application/vnd.amazonaws.card.generic',
    'version': 1,
    'genericAttachments': [{
        'title': "Please select one of the options",
        'subTitle': "{}".format(query),
        'buttons': [
            {
                "text": "test",
                "value": "test"
            },

        ]
    }
    ]
}